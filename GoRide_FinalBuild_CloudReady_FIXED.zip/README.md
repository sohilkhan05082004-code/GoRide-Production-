# GoRide — Android build-ready project

GoRide customer demo app with:
- Taxi booking flow
- Pickup/drop UI
- Vehicle selection and fare
- Driver assigned + tracking-style screen
- Safety/help controls
- Ride completion and rating
- OpenStreetMap + Leaflet map surface

## Maps / Google Cloud
This version does **not** use Google Maps SDK or a Google Maps API key.
The map is rendered in an Android WebView using Leaflet and OpenStreetMap tiles.
Internet permission is required for map tiles.

## Build
Open the project folder in Android Studio and allow Gradle sync. Then use:
**Build → Build APK(s)** for a test APK, or **Build → Generate Signed Bundle / APK** for a Play Store AAB.

Android configuration:
- Namespace: `com.goride.app`
- Application ID: `com.goride.app`
- minSdk: 24
- targetSdk: 35
- compileSdk: 35
- Version: 1.0 (code 1)

## Important
The current map uses demo coordinates and demo driver data. Real production rides require a backend, real GPS updates, authentication, payments, and driver/customer services before public launch.
