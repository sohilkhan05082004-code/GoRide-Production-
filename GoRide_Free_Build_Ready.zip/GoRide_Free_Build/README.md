# GoRide

Android app demo built with Kotlin + Jetpack Compose.

## GitHub APK build

1. Upload the contents of this ZIP to the repository root on the `main` branch.
2. Open **Actions**.
3. Select **GoRide Android Build**.
4. Tap **Run workflow** and select `main`.
5. After the run succeeds, open the run and download the **GoRide-debug-apk** artifact.

The project and workflow force Java and Kotlin compilation to JVM 17.


## Important
This is the current GoRide MVP/demo build. It is intentionally free of Google Maps API requirements and uses OpenStreetMap tiles in the demo screen. Real customer/driver backend, authentication, live location syncing, payments, and production dispatch are not yet implemented.
