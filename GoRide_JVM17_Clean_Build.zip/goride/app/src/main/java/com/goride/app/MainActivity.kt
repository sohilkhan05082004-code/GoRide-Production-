package com.goride.app

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.ui.viewinterop.AndroidView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1479F8)
private val Navy = Color(0xFF10224A)
private val Green = Color(0xFF12B76A)
private val Yellow = Color(0xFFFFB000)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoRideApp() }
    }
}

@Composable
fun GoRideApp() {
    var screen by remember { mutableStateOf("book") }
    var service by remember { mutableStateOf("Ride") }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Blue, background = Color.White)
    ) {
        when (screen) {
            "book" -> BookingScreen(service) { screen = "tracking" }
            "tracking" -> TrackingScreen(service) { screen = "complete" }
            "complete" -> CompleteScreen { screen = "book" }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String = "") {
    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).background(Yellow, RoundedCornerShape(23.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Navigation, null, tint = Navy)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("GoRide", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text("Ride  •  Deliver  •  Together", color = Color.Gray, fontSize = 12.sp)
        }
        OutlinedButton(onClick = {}, shape = RoundedCornerShape(24.dp)) {
            Icon(Icons.Default.HeadsetMic, null); Spacer(Modifier.width(5.dp)); Text("Help")
        }
    }
}

@Composable
fun OSMMap(driver: Boolean = false) {
    val html = remember(driver) { buildMapHtml(driver) }
    Box(Modifier.fillMaxWidth().height(310.dp)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                WebView(context).apply {
                    webViewClient = WebViewClient()
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    loadDataWithBaseURL("https://goride.local/", html, "text/html", "UTF-8", null)
                }
            },
            update = { it.loadDataWithBaseURL("https://goride.local/", html, "text/html", "UTF-8", null) }
        )
        Box(Modifier.align(Alignment.TopEnd).padding(12.dp).background(Color.White, RoundedCornerShape(22.dp)).padding(10.dp)) {
            Text("● Live Tracking", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Row(Modifier.align(Alignment.BottomStart).padding(12.dp).background(Color.White, RoundedCornerShape(24.dp)).padding(12.dp)) {
            Icon(Icons.Default.DirectionsCar, null, tint = Navy); Spacer(Modifier.width(7.dp))
            Text(if (driver) "2.3 km  •  6 min" else "6.8 km  •  18 min", color = Navy, fontWeight = FontWeight.Bold)
        }
    }
}

private fun buildMapHtml(driver: Boolean): String {
    val driverLat = if (driver) 26.8402 else 26.8317
    val driverLon = if (driver) 80.9550 else 80.9211
    return """
<!doctype html><html><head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>html,body,#map{height:100%;margin:0} .leaflet-control-attribution{font-size:9px}</style>
</head><body><div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const pickup=[26.8317,80.9211], drop=[26.8570,81.0079], driver=[$driverLat,$driverLon];
const map=L.map('map',{zoomControl:false}).setView([26.845,80.965],12);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
L.marker(pickup).addTo(map).bindPopup('Pickup: Lucknow Railway Station');
L.marker(drop).addTo(map).bindPopup('Drop: Gomti Nagar');
L.marker(driver).addTo(map).bindPopup('GoRide Driver').openPopup();
L.polyline([pickup,driver,drop],{weight:5}).addTo(map);
</script></body></html>
"""
}

@Composable
fun BookingScreen(service: String, onBook: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Book a Taxi")
        OSMMap()
        Column(Modifier.padding(18.dp)) {
            LocationCard("Pickup Location", "Lucknow Railway Station", Green)
            Spacer(Modifier.height(10.dp))
            LocationCard("Drop Location", "Gomti Nagar", Color.Red)
            Spacer(Modifier.height(20.dp))
            Text("Select Vehicle", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
            Spacer(Modifier.height(10.dp))
            val cars = listOf("Economy" to "₹148", "Comfort" to "₹198", "XL" to "₹266", "Premium" to "₹420")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(cars) { (name, price) ->
                    Card(Modifier.width(145.dp), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            Icon(Icons.Default.DirectionsCar, null, tint = Blue, modifier = Modifier.size(48.dp))
                            Text(name, fontWeight = FontWeight.Bold, color = Navy)
                            Text("AC • Reliable", color = Color.Gray, fontSize = 12.sp)
                            Text(price, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Navy)
                        }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Card(shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocalOffer, null, tint = Blue)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text("Apply Coupon", fontWeight = FontWeight.Bold); Text("Get up to 20% OFF", color = Color.Gray) }
                    Text("₹148", fontWeight = FontWeight.Bold, color = Navy)
                }
            }
            Spacer(Modifier.height(18.dp))
            Button(onClick = onBook, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(18.dp)) {
                Icon(Icons.Default.DirectionsCar, null); Spacer(Modifier.width(8.dp)); Text("Book Ride", fontSize = 20.sp)
            }
        }
    }
}

@Composable
fun LocationCard(label: String, value: String, dot: Color) {
    Card(shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(13.dp).background(dot, RoundedCornerShape(8.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(label, color = Color.Gray); Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Navy) }
            Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
        }
    }
}

@Composable
fun TrackingScreen(service: String, onComplete: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Your driver is on the way")
        Card(Modifier.padding(horizontal = 16.dp), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DirectionsCar, null, tint = Yellow, modifier = Modifier.size(48.dp))
                Spacer(Modifier.width(12.dp))
                Column { Text("Your driver is on the way", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Navy); Text("Arriving in 6 min  •  2.3 km", color = Color.Gray) }
            }
        }
        Spacer(Modifier.height(12.dp))
        OSMMap(true)
        Column(Modifier.padding(18.dp)) {
            Card(shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(70.dp).background(Color.LightGray, RoundedCornerShape(35.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Person, null, modifier = Modifier.size(45.dp))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Amit Kumar", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
                            Text("⭐ 4.8   (432 rides)", color = Navy)
                            Text("Maruti Suzuki Swift", color = Color.Gray)
                            Text("UP32KL 4821", fontWeight = FontWeight.Bold, color = Navy)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Call, null, tint = Blue); Text("Call", color = Navy)
                        }
                    }
                    Spacer(Modifier.height(15.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Stat("Arriving in", "6 min")
                        Stat("Driver", "Near pickup")
                        Stat("Safety", "Verified")
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F8EF))) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, null, tint = Green)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text("Your safety matters", fontWeight = FontWeight.Bold, color = Green); Text("Share ride details with family or friends", color = Color.Gray, fontSize = 12.sp) }
                    Text("Share", color = Blue, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(15.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = {}, modifier = Modifier.weight(1f).height(55.dp)) { Text("Cancel Ride") }
                Button(onClick = onComplete, modifier = Modifier.weight(1f).height(55.dp)) { Text("Complete Demo") }
            }
        }
    }
}

@Composable
fun Stat(title: String, value: String) {
    Column { Text(title, color = Color.Gray, fontSize = 12.sp); Text(value, fontWeight = FontWeight.Bold, color = Navy) }
}

@Composable
fun CompleteScreen(onHome: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Header("Ride Completed!")
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFE9FAF2))) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.CheckCircle, null, tint = Green, modifier = Modifier.size(72.dp))
                Text("Ride Completed!", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("Thank you for choosing GoRide", color = Color.Gray)
            }
        }
        Spacer(Modifier.height(14.dp))
        Card(shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Amit Kumar", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("⭐ 4.8   •   Maruti Suzuki Swift   •   UP32KL 4821", color = Color.Gray)
                Divider(Modifier.padding(vertical = 14.dp))
                Text("Lucknow Railway Station  →  Gomti Nagar", fontWeight = FontWeight.Bold, color = Navy)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Stat("Distance", "2.3 km"); Stat("Ride Time", "20 min"); Stat("Total Fare", "₹148")
                }
                Spacer(Modifier.height(16.dp))
                Text("Payment: UPI (Google Pay)   •   Paid", color = Green, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                Text("Rate Your Driver", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Navy)
                Text("★ ★ ★ ★ ★", fontSize = 30.sp, color = Yellow)
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = onHome, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(18.dp)) {
            Icon(Icons.Default.Home, null); Spacer(Modifier.width(8.dp)); Text("Back to Home", fontSize = 19.sp)
        }
    }
}
